Assignment no 2
Amama ishaq
2025-CS-209
Treasure Hunt
    It is a c++ programme that takes dimensions of map,position of treasure x from user then displays the map
using a function which uses 2 loops one nested inside another with speacial condition for positioning of x
then gives user 4 switch cases all written inside a loop that gives user option to edit the initial coordinates
of the treasure,more the treasure along x axis wuth some positive and negative value similarly for vertical
shifting and when stop programme condition entered stops the programe
     All of the inputs are taken inside do while loops to make sure the entered input is either within the range
or is making logical sense.
